const { MongoClient, ObjectId } = require('mongodb');

const url = 'mongodb://localhost:27017';
const dbName = 'LibraryDB';

async function insertBook() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    const db = client.db(dbName);
    const booksCollection = db.collection('books');

    const book = {
      title: 'The Catcher in the Rye',
      author: 'J.D. Salinger',
      ISBN: '9780316769488',
      genre: 'Fiction',
      availability: true
    };

    const result = await booksCollection.insertOne(book);
    console.log(`Inserted book with ID: ${result.insertedId}`);
  } catch (err) {
    console.error('Error inserting book', err);
  }
}

async function insertMultipleBooks() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    const db = client.db(dbName);
    const booksCollection = db.collection('books');

    const books = [
      {
        title: 'To Kill a Mockingbird',
        author: 'Harper Lee',
        ISBN: '9780061120084',
        genre: 'Fiction',
        availability: true
      },
      {
        title: '1984',
        author: 'George Orwell',
        ISBN: '9780451524935',
        genre: 'Dystopian',
        availability: true
      }
    ];

    const result = await booksCollection.insertMany(books);
    console.log(`${result.insertedCount} books inserted`);
  } catch (err) {
    console.error('Error inserting books', err);
  }
}

async function findAvailableBooks() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    const db = client.db(dbName);
    const booksCollection = db.collection('books');

    const availableBooks = await booksCollection.find({ availability: true }).toArray();
    console.log('Available Books:', availableBooks);
  } catch (err) {
    console.error('Error finding available books', err);
  }
}

async function markBookAsUnavailable() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    const db = client.db(dbName);
    const booksCollection = db.collection('books');

    const bookToUpdate = { ISBN: '9780316769488' };
    const updateResult = await booksCollection.updateOne(bookToUpdate, { $set: { availability: false } });
    console.log(`${updateResult.modifiedCount} book(s) marked as unavailable.`);
  } catch (err) {
    console.error('Error marking book as unavailable', err);
  }
}

async function deleteBook() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    const db = client.db(dbName);
    const booksCollection = db.collection('books');

    const bookToDelete = { ISBN: '9780061120084' };
    const deleteResult = await booksCollection.deleteOne(bookToDelete);
  //  const deleteResult = await booksCollection.deleteMany({});
    console.log(`${deleteResult.deletedCount} book(s) deleted.`);
  } catch (err) {
    console.error('Error deleting book', err);
  }
}

insertBook();
insertMultipleBooks();
findAvailableBooks();
markBookAsUnavailable();
deleteBook();
