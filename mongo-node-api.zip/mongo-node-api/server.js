const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const app = express();
const port = 3000;

// Middleware to parse JSON body
app.use(express.json());

// MongoDB connection URL and DB name
const url = 'mongodb://localhost:27017';
const dbName = 'LibraryDB';
let db;
let booksCollection;

// Function to connect to MongoDB
async function connectMongoDB() {
  const client = new MongoClient(url);
  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    db = client.db(dbName);
    booksCollection = db.collection('books');
  } catch (err) {
    console.error('Failed to connect to MongoDB', err);
  }
}

// Root route (just a welcome message)
app.get('/', (req, res) => {
  res.send('Welcome to the Library API!');
});

// 1. GET /books → Fetch all books
app.get('/books', async (req, res) => {
  try {
    const books = await booksCollection.find().toArray();
    console.log(books); // Check the output in your console
    res.json(books); // Respond with books
  } catch (error) {
    console.error(error); // Log the error if any
    res.status(500).send('Error fetching books');
  }
});

// 2. POST /books → Add a new book
app.post('/books', async (req, res) => {
  try {
    const newBook = req.body;
    const result = await booksCollection.insertOne(newBook);
    res.status(201).json(result.ops[0]);
  } catch (error) {
    console.error(error);
    res.status(500).send('Error adding new book');
  }
});

// 3. PUT /books/:id → Update a book's availability
app.put('/books/:id', async (req, res) => {
  try {
    const bookId = req.params.id;
    const availability = req.body.availability;

    const updateResult = await booksCollection.updateOne(
      { _id: ObjectId(bookId) },
      { $set: { availability } }
    );

    if (updateResult.modifiedCount > 0) {
      res.send('Book availability updated');
    } else {
      res.status(404).send('Book not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Error updating book availability');
  }
});

/* 4. DELETE /books/:id → Delete a book
app.delete('/books/:id', async (req, res) => {
  try {
    const bookId = req.params.id;

    const deleteResult = await booksCollection.deleteOne({ _id: ObjectId(bookId) });

    if (deleteResult.deletedCount > 0) {
      res.send('Book deleted');
    } else {
      res.status(404).send('Book not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Error deleting book');
  }
});
*/
app.delete('/books/:id', async (req, res) => {
  try {
    const bookId = req.params.id;

    // Check if bookId is a valid ObjectId before querying
    if (!ObjectId.isValid(bookId)) {
      return res.status(400).send('Invalid book ID');
    }

    const deleteResult = await booksCollection.deleteOne({ _id: new ObjectId(bookId) });

    if (deleteResult.deletedCount > 0) {
      res.send('Book deleted');
    } else {
      res.status(404).send('Book not found');
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Error deleting book');
  }
});


// Connect to MongoDB and start the server
connectMongoDB()
  .then(() => {
    app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  })
  .catch((err) => {
    console.error('Failed to connect to MongoDB', err);
  });

