Mongo Node API

A simple API project using MongoDB and Node.js.

Introduction

This project sets up a basic Node.js API with MongoDB as the database. It demonstrates how to connect a Node.js application to MongoDB and perform basic CRUD (Create, Read, Update, Delete) operations.

Installation

Follow these steps to set up the project:
# Create and navigate to the project directory
mkdir mongo-node-api
cd mongo-node-api

# Initialize npm
npm init -y

# Install Node.js and NVM (if not installed)
sudo apt install npm
curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash
source ~/.bashrc
nvm install 18
nvm use 18

# Verify installation
node -v
npm --version

# Install MongoDB driver for Node.js
npm install mongodb

# Install MongoDB (if not installed)
sudo apt update
sudo apt install -y mongodb-org

# Start MongoDB service
sudo systemctl start mongod
sudo systemctl enable mongod

# Connect to MongoDB shell
mongosh

Usage

After installing dependencies, you can start the API server and interact with MongoDB.

Running the Project

Run the scripts in the following order:
#1.Start MongoDB Connection Test
node mongodb-connection.js
#2.Initialize the Collection (Book Database Operations)
node collection.js
#3.Start the Express Server
node server.js

##Project Structure

mongo-node-api/
├── collection.js           # Book database operations
├── mongodb-connection.js   # MongoDB client to connect to a local MongoDB server
├── node_modules/           # Installed dependencies
├── package-lock.json       # Dependency lock file
├── package.json            # Project metadata and dependencies
├── server.js               # Express server with CRUD operations




