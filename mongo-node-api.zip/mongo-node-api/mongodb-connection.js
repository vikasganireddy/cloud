const { MongoClient } = require('mongodb');

const url = 'mongodb://localhost:27017';
const dbName = 'LibraryDB';

async function connectMongoDB() {
  const client = new MongoClient(url);

  try {
    await client.connect();
    console.log('Successfully connected to MongoDB');
    const db = client.db(dbName);
    const booksCollection = db.collection('books');
  } catch (err) {
    console.error('Error connecting to MongoDB', err);
  }
}

connectMongoDB();

