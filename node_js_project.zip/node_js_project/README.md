
## Prerequisites
Ensure you have the following installed on your system:

- **Node.js** (Download and install from [Node.js official website](https://nodejs.org/))
- **MongoDB** (Download and install from [MongoDB official website](https://www.mongodb.com/try/download/community))

## Installation Steps

### 1. Install Node.js
Download and install Node.js from [here](https://nodejs.org/), then verify the installation:
```powershell
node -v
npm -v
npm install mongodb
npm install express
```

### 2. Install MongoDB
Download and install MongoDB from [here](https://www.mongodb.com/try/download/community).
Ensure the MongoDB service is running:
```powershell
mongod --version
```

### 3. Start MongoDB
Ensure MongoDB is running before starting the application:
```powershell
mongod
```

### 4. Run the Application
```powershell
node mongodb_project.js
```
The server should start on `http://localhost:3000/`.

## API Usage

### Perform GET, POST, PUT, and DELETE operations in PowerShell

#### **GET all books**
```powershell
Invoke-RestMethod -Uri "http://localhost:3000/books" -Method Get
```

#### **POST a new book**
```powershell
Invoke-RestMethod -Uri "http://localhost:3000/books" -Method Post -Headers @{"Content-Type"="application/json"} -Body '{
  "title": "A Call to Honour",
  "author": "Jaswant Singh",
  "ISBN": "123458",
  "genre": "Fiction",
  "availability": true
}'
```

#### **PUT (Update a book's availability)**
```powershell
Invoke-RestMethod -Uri "http://localhost:3000/books/<BOOK_ID>" -Method Put -Headers @{"Content-Type"="application/json"} -Body '{"availability": false}'
```
Replace `<BOOK_ID>` with the actual ObjectId of the book.

#### **DELETE a book**
```powershell
Invoke-RestMethod -Uri "http://localhost:3000/books/<BOOK_ID>" -Method Delete
```
Replace `<BOOK_ID>` with the actual ObjectId of the book.

## Open in Browser
Once the application is running, you can open the following in your browser:
- `http://localhost:3000/` → Home route
- `http://localhost:3000/books` → View all books (GET request)
