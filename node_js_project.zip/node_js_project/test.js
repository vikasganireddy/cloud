// Import required modules
const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');

// Initialize Express app
const app = express();
const PORT = 3000;

// Middleware to parse JSON
app.use(express.json());

// MongoDB connection details
const DATABASE_URL = 'mongodb://localhost:27017';
const DATABASE_NAME = 'LibraryDB';
let database;
let bookCollection;

/**
 * Function to establish MongoDB connection
 */
async function initializeDatabase() {
    const client = new MongoClient(DATABASE_URL);
    try {
        await client.connect();
        console.log('Connected to MongoDB successfully');
        database = client.db(DATABASE_NAME);
        bookCollection = database.collection('books');
    } catch (error) {
        console.error('MongoDB Connection Error:', error);
    }
}

/**
 * Function to add a single book
 */
async function addSingleBook() {
    try {
        const newBook = {
            title: 'Revolution 2020',
            author: 'Chetan Bhagat',
            ISBN: '123455',
            genre: 'Thriller',
            availability: true
        };
        
        const result = await bookCollection.insertOne(newBook);
        console.log(`New book added with ID: ${result.insertedId}`);
    } catch (error) {
        console.error('Error adding book:', error);
    }
}

/**
 * Function to add multiple books
 */
async function addMultipleBooks() {
    try {
        const booksArray = [
            { title: 'A Brush with Life ', author: 'Satish Gujral', ISBN: '123456', genre: 'Dystopian', availability: true },
            { title: 'A House for Mr. Biswas ', author: 'V.S. Naipaul', ISBN: '123457', genre: 'Horor', availability: true }
        ];
        
        const result = await bookCollection.insertMany(booksArray);
        console.log(`${result.insertedCount} books added successfully`);
    } catch (error) {
        console.error('Error adding multiple books:', error);
    }
}

/**
 * Function to retrieve available books
 */
async function fetchAvailableBooks() {
    try {
        const availableBooks = await bookCollection.find({ availability: true }).toArray();
        console.log('Available Books:', availableBooks);
    } catch (error) {
        console.error('Error fetching books:', error);
    }
}

/**
 * Function to mark a book as unavailable
 */
async function updateBookAvailability() {
    try {
        const bookQuery = { ISBN: '123457' };
        const updateResult = await bookCollection.updateOne(bookQuery, { $set: { availability: false } });
        console.log(`Updated ${updateResult.modifiedCount} book(s) as unavailable.`);
    } catch (error) {
        console.error('Error updating book:', error);
    }
}

/**
 * Function to delete a book
 */
async function removeBook() {
    try {
        const bookQuery = { ISBN: '123457' };
        const deleteResult = await bookCollection.deleteOne(bookQuery);
        console.log(`${deleteResult.deletedCount} book(s) deleted.`);
    } catch (error) {
        console.error('Error deleting book:', error);
    }
}

// Express.js API Endpoints

// Home Route
app.get('/', (req, res) => {
    res.send('Welcome to the Library Management API');
});

// Fetch all books
app.get('/books', async (req, res) => {
    try {
        const books = await bookCollection.find().toArray();
        res.json(books);
    } catch (error) {
        res.status(500).send('Error retrieving books');
    }
});

// Add a new book
app.post('/books', async (req, res) => {
    try {
        const newBook = req.body;
        const result = await bookCollection.insertOne(newBook);
        res.status(201).json({ id: result.insertedId, message: 'Book added successfully' });
    } catch (error) {
        res.status(500).send('Error adding book');
    }
});

// Update book availability
app.put('/books/:id', async (req, res) => {
    try {
        const bookId = req.params.id;
        const availabilityStatus = req.body.availability;

        if (!ObjectId.isValid(bookId)) {
            return res.status(400).send('Invalid book ID');
        }

        const updateResult = await bookCollection.updateOne(
            { _id: new ObjectId(bookId) },
            { $set: { availability: availabilityStatus } }
        );

        if (updateResult.modifiedCount > 0) {
            res.send('Book availability updated successfully');
        } else {
            res.status(404).send('Book not found');
        }
    } catch (error) {
        res.status(500).send('Error updating book availability');
    }
});

// Delete a book
app.delete('/books/:id', async (req, res) => {
    try {
        const bookId = req.params.id;
        
        if (!ObjectId.isValid(bookId)) {
            return res.status(400).send('Invalid book ID');
        }
        
        const deleteResult = await bookCollection.deleteOne({ _id: new ObjectId(bookId) });
        
        if (deleteResult.deletedCount > 0) {
            res.send('Book deleted successfully');
        } else {
            res.status(404).send('Book not found');
        }
    } catch (error) {
        res.status(500).send('Error deleting book');
    }
});

// Start the server after connecting to MongoDB and call necessary functions
initializeDatabase().then(async () => {
    console.log('Initializing sample data...');
    await addSingleBook();
    await addMultipleBooks();
    await fetchAvailableBooks();
    await updateBookAvailability();
    await removeBook();
    
    app.listen(PORT, () => {
        console.log(`Server running on http://localhost:${PORT}`);
    });
}).catch((error) => {
    console.error('Error starting the server:', error);
});

