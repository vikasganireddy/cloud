// sensor1.js
const mqtt = require('mqtt');

// MQTT Broker
const client = mqtt.connect('mqtt://test.mosquitto.org');  // Changed broker

// Simulate temperature readings with a function
function createSensorData(sensorId) {
    const temp = (Math.random() * 15 + 18).toFixed(2); // Random temp between 18 and 33
    return {
        sensor: sensorId,
        temperature: temp,
        timestamp: new Date().toISOString(),
    };
}

// Publish the data every 2 seconds
function sendData() {
    const data1 = createSensorData('sensor1');
    const data2 = createSensorData('sensor2');

    client.publish('/home/sensor1', JSON.stringify(data1));
    client.publish('/home/sensor2', JSON.stringify(data2));

    console.log(`Data published to sensor1: ${JSON.stringify(data1)}`);
    console.log(`Data published to sensor2: ${JSON.stringify(data2)}`);
}

// Connect to the broker and start sending data
client.on('connect', () => {
    console.log('MQTT Broker connected');
    setInterval(sendData, 2000); // Every 2 seconds
});

// Handle any connection issues
client.on('error', (err) => {
    console.error('Connection Error:', err);
});
