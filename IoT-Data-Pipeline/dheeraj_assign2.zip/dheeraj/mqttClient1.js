// mqttClient.js (Version 2)

const mqtt = require('mqtt');
const { MongoClient } = require('mongodb');

const mongoUrl = 'mongodb://127.0.0.1:27017';
const dbName = 'iot_database';

let collection;

async function initializeDB() {
    const client = new MongoClient(mongoUrl);
    await client.connect();
    console.log('Connected to MongoDB');
    collection = client.db(dbName).collection('sensor_data');
}

async function storeSensorData(topic, message) {
    try {
        const data = JSON.parse(message.toString());
        await collection.insertOne({
            sensor: data.sensor,
            temperature: data.temperature,
            timestamp: data.timestamp,
        });
        console.log(`Data from ${topic} saved:`, data);
    } catch (error) {
        console.error('Error storing data:', error);
    }
}

async function startMQTT() {
    const client = mqtt.connect('mqtt://test.mosquitto.org');

    client.on('connect', () => {
        console.log('Connected to MQTT broker');
        client.subscribe(['/home/sensor1', '/home/sensor2']);
    });

    client.on('message', storeSensorData);
    client.on('error', (err) => console.error('MQTT error:', err));
}

async function main() {
    await initializeDB();
    await startMQTT();
}

main().catch(console.error);

