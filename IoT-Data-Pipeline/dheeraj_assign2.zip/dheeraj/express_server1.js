// expressServer.js (Version 2)

const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const PORT = 3000;
const mongoUrl = 'mongodb://localhost:27017';
const dbName = 'iot_database';

let collection;

// Initialize MongoDB Connection
async function connectMongoDB() {
    try {
        const client = new MongoClient(mongoUrl);
        await client.connect();
        console.log('Connected to MongoDB');
        collection = client.db(dbName).collection('sensor_data');
    } catch (error) {
        console.error('Error connecting to MongoDB:', error);
    }
}
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>IoT Sensor Dashboard</title>
            <style>
                body {
                    font-family: 'Segoe UI', sans-serif;
                    background-color: #f4f4f4;
                    text-align: center;
                    padding: 50px;
                }
                .loader {
                    border: 6px solid #f3f3f3;
                    border-top: 6px solid #3498db;
                    border-radius: 50%;
                    width: 40px;
                    height: 40px;
                    animation: spin 1s linear infinite;
                    display: block;
                    margin: 20px auto;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                .btn {
                    display: inline-block;
                    padding: 10px 20px;
                    background: #3498db;
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    margin-top: 20px;
                    transition: background 0.3s;
                }
                .btn:hover {
                    background: #2980b9;
                }
            </style>
        </head>
        <body>
            <h1> IoT Sensor Dashboard</h1>
            <p>Fetching real-time sensor data...</p>
            <div class="loader"></div>
            <a class="btn" href="/data"> View Sensor Data</a>
        </body>
        </html>
    `);
});

// GET /data endpoint to fetch sensor readings
app.get('/data', async (req, res) => {
    try {
        if (!collection) {
            return res.status(500).json({ error: 'Database not initialized' });
        }

        const data = await collection.find({}).toArray();
        res.json(data);
    } catch (error) {
        console.error('Error retrieving data:', error);
        res.status(500).json({ error: 'Failed to fetch sensor data' });
    }
});

// Start the server after DB connection is established
connectMongoDB().then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on http://localhost:${PORT}`);
    });
});

