const express = require("express");
const { MongoClient } = require("mongodb");

const app = express();
const PORT = 3000;

// MongoDB connection URI (Modify if using a local instance)
const mongoURI = "mongodb://127.0.0.1:27017";
const dbName = "iot_data";
const collectionName = "sensor_readings";

// Connect to MongoDB
async function connectToMongo() {
  try {
    const client = new MongoClient(mongoURI);
    await client.connect();
    console.log("Connected to MongoDB");
    return client.db(dbName).collection(collectionName);
  } catch (error) {
    console.error("MongoDB Connection Error:", error);
    throw new Error("Database connection failed");
  }
}
app.get('/', (req, res) => {
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>IoT Sensor Data API</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #121212;
                    color: #ffffff;
                    text-align: center;
                    padding: 50px;
                }
                a {
                    color: #1db954;
                    text-decoration: none;
                    font-size: 18px;
                    font-weight: bold;
                }
                a:hover {
                    text-decoration: underline;
                }
            </style>
        </head>
        <body>
            <h1> Welcome to IoT Sensor Data API</h1>
            <p>Click to view your sensor data.</p>
            <p> <a href="/data">View Sensor Readings</a></p>
        </body>
        </html>
    `);
});

// API Endpoint to retrieve stored sensor data
app.get("/data", async (req, res) => {
  try {
    const collection = await connectToMongo();
    const sensorData = await collection.find().toArray();
    res.json(sensorData);
  } catch (error) {
    console.error("Error fetching sensor data:", error);
    res.status(500).json({ error: "Failed to retrieve data" });
  }
});

// Start the Express server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

