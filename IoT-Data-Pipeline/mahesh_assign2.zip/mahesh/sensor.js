const mqtt = require("mqtt");

// Connect to an MQTT broker (use a local broker or a public one like test.mosquitto.org)
const brokerUrl = "mqtt://test.mosquitto.org"; // Change this if using a local broker
const client = mqtt.connect(brokerUrl);

client.on("connect", () => {
  console.log("Connected to MQTT broker");
//   setInterval(publishSensorData, 2000); // Publish every 2 seconds

  // Function to generate random temperature data
  function generateTemperature() {
    return (Math.random() * (35 - 15) + 15).toFixed(2); // Random temp between 15°C and 35°C
  }

  // Publish data every 2 seconds
  setInterval(() => {
    const sensor1Data = { sensor: "sensor1", temperature: generateTemperature(), timestamp: new Date() };
    const sensor2Data = { sensor: "sensor2", temperature: generateTemperature(), timestamp: new Date() };

    // Publish data to MQTT topics
    client.publish("/home/sensor1", JSON.stringify(sensor1Data));
    client.publish("/home/sensor2", JSON.stringify(sensor2Data));

    console.log("Published:", sensor1Data, sensor2Data);
  }, 2000);
});

client.on("error", (err) => {
  console.error("MQTT Error:", err);
});

