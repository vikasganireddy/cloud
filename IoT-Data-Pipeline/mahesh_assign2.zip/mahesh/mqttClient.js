const mqtt = require("mqtt");
const { MongoClient } = require("mongodb");

// MongoDB connection URI (Change if using a local MongoDB instance)
const mongoURI = "mongodb://127.0.0.1:27017";
const dbName = "iot_data";
const collectionName = "sensor_readings";

// MQTT Broker URL
const brokerUrl = "mqtt://test.mosquitto.org"; // Change if using a local broker

// Connect to MongoDB
async function connectToMongo() {
  const client = new MongoClient(mongoURI);
  await client.connect();
  console.log("Connected to MongoDB");
  return client.db(dbName).collection(collectionName);
}

// Connect to MQTT broker
const mqttClient = mqtt.connect(brokerUrl);

mqttClient.on("connect", async () => {
  console.log("Connected to MQTT broker, subscribing to topics...");
  
  // Subscribe to sensor topics
  mqttClient.subscribe(["/home/sensor1", "/home/sensor2"], (err) => {
    if (err) console.error("Subscription error:", err);
    else console.log("Subscribed to /home/sensor1 and /home/sensor2");
  });

  // Get MongoDB collection
  const collection = await connectToMongo();

  // Listen for incoming messages
  mqttClient.on("message", async (topic, message) => {
    try {
      const data = JSON.parse(message.toString());
      data.receivedAt = new Date(); // Add timestamp when received

      // Store data in MongoDB
      await collection.insertOne(data);
      console.log("Stored in MongoDB:", data);
    } catch (error) {
      console.error("Error processing message:", error);
    }
  });
});

mqttClient.on("error", (err) => {
  console.error("MQTT Error:", err);
});

