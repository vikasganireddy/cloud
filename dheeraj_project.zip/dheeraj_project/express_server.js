// Import necessary modules
const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');

// Initialize Express application
const app = express();
const PORT = 2000;

// Middleware to handle JSON requests
app.use(express.json());

// MongoDB Configuration
const DATABASE_URL = 'mongodb://localhost:27017';
const DATABASE_NAME = 'LibraryDB';
let database;
let booksCollection;

/**
 * Establishes connection with MongoDB
 */
async function connectToDatabase() {
    const client = new MongoClient(DATABASE_URL);
    try {
        await client.connect();
        console.log('Connected to MongoDB successfully');
        database = client.db(DATABASE_NAME);
        booksCollection = database.collection('books');
    } catch (error) {
        console.error('Failed to connect to MongoDB:', error);
    }
}

/**
 * Inserts a single book into the collection
 */
async function insertSingleBook() {
    try {
        const book = {
            title: 'The Power of Habit',
            author: 'Charles Duhigg',
            ISBN: '0001',
            genre: 'Self-Help',
            availability: true
        };
        
        const result = await booksCollection.insertOne(book);
        console.log(`Book added with ID: ${result.insertedId}`);
    } catch (error) {
        console.error('Error inserting book:', error);
    }
}

/**
 * Inserts multiple books into the collection
 */
async function insertMultipleBooks() {
    try {
        const bookList = [
            { title: 'Rich Dad Poor Dad', author: 'Robert T. Kiyosaki', ISBN: '0002', genre: 'Finance', availability: true },
            { title: 'The 5 AM Club', author: 'Robin Sharma', ISBN: '0003', genre: 'Personal Development', availability: true },
	    { title: 'The Psychology of Money', author: 'Morgan', ISBN: '0004', genre: 'Finance', availability: true }
        ];

        const result = await booksCollection.insertMany(bookList);
        console.log(`${result.insertedCount} books successfully inserted.`);
    } catch (error) {
        console.error('Error inserting multiple books:', error);
    }
}

/**
 * Retrieves all available books
 */
async function getAvailableBooks() {
    try {
        const books = await booksCollection.find({ availability: true }).toArray();
        console.log('List of Available Books:', books);
    } catch (error) {
        console.error('Error retrieving books:', error);
    }
}

/**
 * Updates the availability status of a book
 */
async function modifyBookAvailability() {
    try {
        const filter = { ISBN: '123457' };
        const update = { $set: { availability: false } };
        
        const result = await booksCollection.updateOne(filter, update);
        console.log(`Updated availability status of ${result.modifiedCount} book(s).`);
    } catch (error) {
        console.error('Error updating book status:', error);
    }
}

/**
 * Removes a book from the collection
 */
async function deleteBook() {
    try {
        const filter = { ISBN: '123457' };
        const result = await booksCollection.deleteOne(filter);
        console.log(`${result.deletedCount} book(s) removed.`);
    } catch (error) {
        console.error('Error removing book:', error);
    }
}

// Express.js API Endpoints

// Home Route
app.get('/', (req, res) => {
    res.send('Welcome to the Library API');
});

// Retrieve all books
app.get('/books', async (req, res) => {
    try {
        const books = await booksCollection.find().toArray();
        res.json(books);
    } catch (error) {
        res.status(500).send('Failed to fetch books');
    }
});

// Add a new book
app.post('/books', async (req, res) => {
    try {
        const book = req.body;
        const result = await booksCollection.insertOne(book);
        res.status(201).json({ id: result.insertedId, message: 'Book added successfully' });
    } catch (error) {
        res.status(500).send('Failed to add book');
    }
});

// Update availability of a book
app.put('/books/:id', async (req, res) => {
    try {
        const bookId = req.params.id;
        const { availability } = req.body;

        if (!ObjectId.isValid(bookId)) {
            return res.status(400).send('Invalid Book ID');
        }

        const result = await booksCollection.updateOne(
            { _id: new ObjectId(bookId) },
            { $set: { availability } }
        );

        result.modifiedCount > 0 ? res.send('Book availability updated') : res.status(404).send('Book not found');
    } catch (error) {
        res.status(500).send('Error updating book status');
    }
});

// Delete a book
app.delete('/books/:id', async (req, res) => {
    try {
        const bookId = req.params.id;

        if (!ObjectId.isValid(bookId)) {
            return res.status(400).send('Invalid Book ID');
        }

        const result = await booksCollection.deleteOne({ _id: new ObjectId(bookId) });

        result.deletedCount > 0 ? res.send('Book deleted successfully') : res.status(404).send('Book not found');
    } catch (error) {
        res.status(500).send('Error deleting book');
    }
});

// Initialize database and start server
async function initializeServer() {
    try {
        await connectToDatabase();
        console.log('Setting up initial data...');
        await insertSingleBook();
        await insertMultipleBooks();
        await getAvailableBooks();
        await modifyBookAvailability();
        await deleteBook();

        app.listen(PORT, () => {
            console.log(`Server is running at http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
    }
}

initializeServer();
