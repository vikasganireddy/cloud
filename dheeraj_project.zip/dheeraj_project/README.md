
1. Install Node.js
2. create directory of your choice
3. npm install mongodb
4. npm install express

node express_server.js
The server should start on `http://localhost:2000/`.


### Perform GET, POST, PUT, and DELETE operations in PowerShell

#### **GET all books**
Invoke-RestMethod -Uri "http://localhost:2000/books" -Method Get

#### **POST a new book**
Invoke-RestMethod -Uri "http://localhost:2000/books" -Method Post -Headers @{"Content-Type"="application/json"} -Body '{
  "title": "The Rise",
  "author": "Vikash",
  "ISBN": "0005",
  "genre": "Thriller",
  "availability": true
}'

#### **PUT (Update a book's availability)**
Invoke-RestMethod -Uri "http://localhost:2000/books/<BOOK_ID>" -Method Put -Headers @{"Content-Type"="application/json"} -Body '{"availability": false}'
Replace `<BOOK_ID>` with the actual ObjectId of the book.

#### **DELETE a book**
Invoke-RestMethod -Uri "http://localhost:2000/books/<BOOK_ID>" -Method Delete
Replace `<BOOK_ID>` with the actual ObjectId of the book.

## Open in Browser
Once the application is running, you can open the following in your browser:
- `http://localhost:2000/` → Home route
- `http://localhost:2000/books` → View all books (GET request)
